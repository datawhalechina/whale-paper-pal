export {
  StateMachine,
  getExpectedTransition,
  getAllValidTransitions,
  type AvatarState,
  type TransitionTrigger,
  type StateTransition,
} from './StateMachine';
