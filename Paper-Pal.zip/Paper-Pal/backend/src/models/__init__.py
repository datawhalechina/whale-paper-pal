"""Data models for Paper Pal."""

from .paper import Paper, ScoredPaper

__all__ = ["Paper", "ScoredPaper"]
