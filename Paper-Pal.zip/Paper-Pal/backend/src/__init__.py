"""Paper Pal Backend - AI Paper Reading Assistant."""
